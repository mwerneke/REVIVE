# 🎯 REVIVE Deal Analyzer - Quick Reference

## 1-Minute Overview

The tool answers one question: **Should I take this deal?**

**Input:**
- How many skins? (Volume)
- What price? (Selling price)
- Any discount? (%)
- When do they pay? (Payment days)

**Output:**
- 💵 How much profit you make
- 🔴/🟡/🟢 Whether it's risky
- ✅/⚠️/❌ Take it or not

---

## Your Pricing (Reference)

| Volume | Your Cost | Standard Price | Max Discount* |
|--------|-----------|----------------|---------------|
| 5K | $1.80 | $4.50 | $4.05 (-10%) |
| 10K | $1.70 | $4.25 | $3.83 (-10%) |
| 15K | $1.65 | $4.13 | $3.72 (-10%) |
| 20K | $1.58 | $3.95 | $3.55 (-10%) |
| 25K | $1.56 | $3.90 | $3.51 (-10%) |
| 30K+ | $1.50 | $3.75 | $3.38 (-10%) |

*Recommended max discount = 10-15% (still keeps you profitable)

---

## Decision Matrix

### Deal Size

| Volume | Risk | Action |
|--------|------|--------|
| <5,000 | 🟡 | Can do, but verify they won't shrink order |
| 5K-15K | 🟢 | Sweet spot. Easy to execute. |
| 15K-40K | 🟢 | Great. Economies of scale kick in. |
| 40K+ | 🟢 | Excellent. Max profitability. |

### Payment Terms

| Payment | Risk | Action |
|---------|------|--------|
| Upfront/Net 15 | 🟢 | Take it. No cash flow risk. |
| Net 30 | 🟢 | Ideal. Standard terms. |
| Net 45 | 🟡 | Acceptable. Minor cash tie-up. |
| Net 60 | 🟡 | Risky. Significant cash tied up. |
| Net 90+ | 🔴 | Don't accept unless deal is huge. |

### Discount

| Discount | Risk | Action |
|----------|------|--------|
| 0-5% | 🟢 | Good. Keep margins high. |
| 5-10% | 🟢 | Acceptable. Still profitable. |
| 10-15% | 🟡 | Proceed with caution. Verify volume. |
| 15-25% | 🔴 | Decline unless volume is massive (50K+). |
| 25%+ | 🔴 | Too aggressive. Renegotiate. |

---

## Quick Analysis Formula

**Profit per unit = (Price × 1 - Discount%) - Your Cost**

Examples:

```
Deal 1: 10K units at $4.00, no discount
Cost: $1.70
Profit/unit: $4.00 - $1.70 = $2.30
Total profit: $2.30 × 10,000 = $23,000 ✅

Deal 2: 20K units at $3.50 (10% off $3.88), Net 60
Cost: $1.58
Profit/unit: $3.50 - $1.58 = $1.92
Total profit: $1.92 × 20,000 = $38,400
BUT cash tied up 60 days = $3,500 ⚠️
Still good, but negotiate to Net 45
```

---

## Red Flags to Watch

### 🔴 NEVER Accept These Combinations:

- **Small volume + deep discount** (e.g., 5K units, 20% off)
- **Long payment terms + small discount** (e.g., 10K, 10% off, Net 90)
- **Vague terms** (e.g., "We'll figure out payment later")
- **"We need exclusive rights"** without long-term commitment
- **"Volume will grow 50% next month"** (get it in writing!)

### 🟡 NEGOTIATE These:

- **Net 60+ payment terms** → Propose Net 45 or prepay 50%
- **>15% discount** → Counter with volume increase instead
- **Tight deadlines + low volume** → Offer premium for rush
- **Payment contingent on approval** → Require signed PO first

### 🟢 ACCEPT These:

- **Net 30 or better**
- **<15% discount**
- **Volume ≥5K units**
- **Repeat customer** (proven payment history)

---

## Real Deal Examples

### EXAMPLE 1: "Easy Win"
```
Retailer wants: 10K units at standard price, Net 30

Analysis:
Volume: 10K ✅
Cost: $1.70/unit
Price: $4.25/unit
Discount: 0% ✅
Payment: Net 30 ✅

Result: $25,480 profit (60% margin)
Decision: ✅ TAKE IT (2 minutes to decide)
```

### EXAMPLE 2: "Negotiate"
```
Brand wants: 25K units at $3.50 (10% off), Net 60

Analysis:
Volume: 25K ✅
Cost: $1.56/unit
Price: $3.50 (vs. standard $3.90) 
Discount: 10% (they asked for 15, you said no)
Payment: Net 60 ⚠️

Profit/unit: $1.94
Total profit: $48,500 ✅ but...
Cash tied up: $4,375 ⚠️

Decision: ✅ ACCEPT IF you can negotiate Net 45
Counter-offer: "We'll do Net 60 if you commit to monthly orders"
```

### EXAMPLE 3: "Pass"
```
Promo house wants: 3K units at $3.00, Net 90

Analysis:
Volume: 3K ❌ (below 5K)
Cost: $1.80/unit (small volume premium)
Price: $3.00 ❌ (deep discount)
Payment: Net 90 ❌ (major red flag)

Profit/unit: $1.20
Total profit: $3,600 ❌ Small
But: $2,700 tied up for 90 days ❌

Decision: ❌ PASS
Counter-offer: "Minimum 5K units, Net 30, or we can't do it"
```

### EXAMPLE 4: "Timing Issue"
```
Customer wants: 15K units at $4.00, Net 30, ASAP

Analysis:
Volume: 15K ✅
Cost: $1.65/unit ✅
Price: $4.00 ✅ (above standard $4.13)
Discount: 0% ✅
Payment: Net 30 ✅

Profit/unit: $2.35
Total profit: $35,250 ✅

But: They need it in 2 weeks, you have 1-week lead time
Decision: ✅ TAKE IT (You can do it)
Or ❌ PASS (You can't deliver in time)
```

---

## Tool Tips & Tricks

### Tip 1: Always Include Overhead
If you have monthly rent/staff costs, include them.
This shows true profitability, not just "gross profit."

### Tip 2: Save Every Deal
Build a history. Later, you can see which customers were most profitable.

### Tip 3: Use It for Negotiations
Customer: "Will you do 15% off?"
You: *Input into tool, shows loss*
You: "No, but I can do 8% off if you go to 20K units."
*Input again, shows profit*
Boom. Data-driven negotiation.

### Tip 4: Track Actuals vs. Forecast
- Did they actually order the volume?
- Did they pay on time?
- What was the real profit?
Compare to what the tool predicted.

### Tip 5: Update if Costs Change
Your costs are locked in at current rates.
If material prices spike, update the tool.

---

## When to Use the Tool

✅ **Before every deal** (takes 2 minutes)
✅ **During negotiations** (show the math)
✅ **For "what-if" analysis** (volume vs. price vs. payment)
✅ **At month-end** (compare forecast vs. actual)

❌ **Don't** overthink it. It's a guide, not gospel.
❌ **Don't** let perfect be the enemy of good. Take a slightly risky deal if you need the volume.

---

## Success Metrics to Track

Every month, record:

| Customer | Volume | Planned Profit | Actual Profit | On-Time Payment? | Reorder? |
|----------|--------|-----------------|---------------|--------------------|----------|
| Brand A | 10K | $25,480 | $24,900 | ✅ | ✅ |
| Retailer B | 15K | $37,095 | $36,500 | ⚠️ (Late 5 days) | ? |
| Promo Co. | 5K | $13,490 | $13,200 | ❌ (Late 30 days) | ? |

**Goal:**
- Forecast accuracy: ±5%
- On-time payment: 95%+ customers
- Reorder rate: 60%+

If you're hitting these, you're running a healthy business.

---

## Cheat Sheet for Sales Team

If sharing with your sales reps:

**Print this and tape it above their desk:**

```
REVIVE DEAL CHECKLIST

Before you quote:
☐ Volume ≥ 5,000 units?
☐ Price at least our standard for that volume?
☐ Discount ≤ 15%?
☐ Payment terms ≤ Net 45?

If YES to all 4: ✅ SAFE TO QUOTE
If NO to any: ⚠️ RUN IT BY THE BOSS

When in doubt, plug it into REVIVE Deal Analyzer.
2 minutes. No excuses. Every deal.
```

---

## Support

If the tool breaks or you want to modify it:
- The code is in `revive_app.py`
- It's written in Python (easy to modify)
- Adding new features takes 1-2 hours

Just ask and I can update it.

---

**Version 1.0 | April 2024**
**Built for REVIVE Pickleball Skins**
